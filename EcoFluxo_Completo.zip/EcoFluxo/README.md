# EcoFluxo — Backend consolidado

Esta pasta reúne os arquivos dos dois pacotes enviados (ZIP e RAR).

## O que foi reunido

- Autenticação de usuário com login e verificação em duas etapas (2FA).
- Serviço de envio de código por e-mail.
- Rotas e controllers de usuários, ecopontos e lixeiras.
- Prisma, schema, seed e migrações.
- Swagger.
- Configuração do Prisma 7 ajustada para o nome padrão `prisma.config.ts`.
- Middleware JWT alinhado ao cookie `token` e ao campo `perfil`.

## Requisitos

- Node.js compatível com as dependências do projeto.
- MySQL/MariaDB (por exemplo, pelo XAMPP).
- Uma conta SMTP para envio do código 2FA.

## Como configurar

1. Entre na pasta `Backend`.
2. Copie `.env.example` para `.env`.
3. Preencha `DATABASE_URL`, `FRONTEND_URL`, `JWT_SECRET` e as variáveis de e-mail.
4. Instale as dependências:

   ```bash
   npm install
   ```

5. Gere o Prisma Client:

   ```bash
   npx prisma generate
   ```

6. Se o banco ainda não tiver as tabelas, aplique as migrações:

   ```bash
   npx prisma migrate dev
   ```

7. Inicie o backend:

   ```bash
   npm run dev
   ```

8. Para gerar a documentação Swagger:

   ```bash
   npm run swagger
   ```

   A documentação fica em `http://localhost:5000/docs`.

## Rotas principais

### Usuários — `/ecofluxo`

- `POST /login`
- `POST /verify-2fa`
- `POST /logout`
- `POST /create` (controller ainda contém o esqueleto original, não uma implementação completa)

### Ecopontos — `/ecopontos`

- `POST /createEcoponto`
- `GET /`

### Lixeiras — `/lixeiras`

- `POST /createLixeira`
- `GET /`

## Observações importantes

- O arquivo `.env` original foi substituído por `.env.example` para não distribuir senhas, tokens ou credenciais privadas. Crie seu próprio `.env`.
- O `UsuarioController.Create`, `Reset` e `forgotPassword` ainda são estruturas vazias que já estavam nos arquivos enviados; não foram inventadas implementações.
- O middleware de autenticação está pronto, mas as rotas de ecopontos e lixeiras foram mantidas sem exigir token, como na versão que implementava esses recursos. Antes de publicar, defina quais rotas devem exigir autenticação e perfil.
- Foi mantida somente a migração mais recente de 2FA (`20261111043456_segundo_fator_login`), porque o outro pacote tinha outra migração com as mesmas duas colunas. Não execute migrações às cegas em um banco que já tenha uma das versões aplicada. Confira `prisma migrate status` e a tabela `_prisma_migrations` antes.
- O `seed` cria um usuário gestor de demonstração com credenciais definidas no próprio arquivo `prisma/seed.ts`. Altere a senha de demonstração antes de usar em ambiente real.
