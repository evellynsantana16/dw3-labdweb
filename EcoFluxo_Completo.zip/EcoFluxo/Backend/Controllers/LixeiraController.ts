//fazer cadastrar e buscarTodos 
import prisma from "../lib/prisma.js";
import type {Request, Response} from "express";
export default class LixeiraController{
  

    // cadastro de lixeira
    static async Create(req: Request, res: Response) {
        try {

            // 1 Receber os dados do Frontend
            const {
                uuid_sensor,
                tipo,
                volume_max,
                nivel_cheio,
                ecoponto_id
            } = req.body;

            // 2 Validar os campos que são obrigatórios
            if (
                !uuid_sensor ||
                !tipo ||
                volume_max == null ||
                nivel_cheio == null ||
                ecoponto_id == null
            ) {
                return res.status(400).json({
                    mensagem: "Preencha todos os campos obrigatórios."
                });
            }

            // 3 Verificar se o ecoponto existe
            const ecoponto = await prisma.ecoponto.findUnique({
                where: {
                    //converte um valor para o tipo numérico
                    id: Number(ecoponto_id)
                }
            });

            if (!ecoponto) {
                return res.status(404).json({
                    mensagem: "Ecoponto não encontrado."
                });
            }

            // 4 Cadastrar a lixeira no banco
            const novaLixeira = await prisma.lixeira.create({
                data: {
                    uuid_sensor,
                    tipo,
                    volume_max: Number(volume_max),
                    nivel_cheio: Number(nivel_cheio),
                    ecoponto_id: Number(ecoponto_id)
                }
            });

            // 5 Retornar resposta de sucesso e erro
            return res.status(201).json({
                mensagem: "Lixeira cadastrada com sucesso!",
                lixeira: novaLixeira
            });

        } catch (error) {

            console.error(error);

            return res.status(500).json({
                mensagem: "Erro ao cadastrar lixeira."
            });

        }
    }// fim do create




    // metodo buscarTodos
static async getLixeiras(req: Request, res: Response) {
    try {

        //recebe também os dados do ecoponto relacionado, como nome, cidade e endereço. sem, apareceria só o ID
        const lixeiras = await prisma.lixeira.findMany({
            include: {
                ecoponto: true
            }
        });

        return res.status(200).json(lixeiras);

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            mensagem: "Erro ao buscar lixeiras."
        });

    }
}//fim metodo buscarTodos
}
