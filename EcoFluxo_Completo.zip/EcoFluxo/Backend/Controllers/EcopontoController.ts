
import prisma from "../lib/prisma.js";
import type {Request, Response} from "express";

export default class EcopontoController {

    //Metodo create
    static async Create(req:Request, res:Response) {
        try {
            const {
                nome,
                latitude,
                longitude,
                descricao,
                cep,
                logradouro,
                numero,
                bairro,
                cidade,
                uf,
                nota
            } = req.body;

            //verificação dos dados obrigatórios
            if (!nome || !latitude || !longitude) {
                return res.status(400).json({
                    mensagem: "Preencha os campos obrigatórios."
                });
            }

            //inserir no banco de dados
            const novoEcoponto = await prisma.ecoponto.create({
                data: {
                    nome,
                    latitude,
                    longitude,
                    descricao,
                    cep,
                    logradouro,
                    numero,
                    bairro,
                    cidade,
                    uf,
                    nota
                }
            });

            return res.status(201).json({
                mensagem: "Ecoponto cadastrado com sucesso!",
                ecoponto: novoEcoponto
            });

        } catch (error) {
            console.error(error);

            return res.status(500).json({
                mensagem: "Erro ao cadastrar ecoponto."
            });
        }
    }    //Metodo create

    //metodo buscarTodos Ecoponto
    static async getEcopontos(req:Request, res:Response) {
        try {

            const ecopontos = await prisma.ecoponto.findMany({
                include: {
                    lixeiras: true
                }
            });

            return res.status(200).json(ecopontos);

        } catch (error) {
            console.error(error);

            return res.status(500).json({
                mensagem: "Erro ao buscar ecopontos."
            });
        }
    } //fim metodo buscarTodos Ecoponto
}
