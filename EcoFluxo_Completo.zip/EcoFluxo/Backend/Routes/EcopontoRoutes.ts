import { Router } from "express";
import EcopontoController from "../Controllers/EcopontoController.js";

const routerEcoponto = Router();

// Cadastrar ecoponto
routerEcoponto.post("/createEcoponto", EcopontoController.Create);

// Buscar todos os ecopontos
routerEcoponto.get("/", EcopontoController.getEcopontos);

export default routerEcoponto;
