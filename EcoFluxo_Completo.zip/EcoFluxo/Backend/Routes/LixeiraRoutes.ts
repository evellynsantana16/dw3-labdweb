
import { Router } from 'express';
import LixeiraController from '../Controllers/LixeiraController.js';

const routerLixeira = Router();

routerLixeira.post( "/createLixeira", LixeiraController.Create
);

routerLixeira.get( "/", LixeiraController.getLixeiras
);

export default routerLixeira;
