import "dotenv/config";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import swaggerUi from "swagger-ui-express";

import routerUsuario from "./Routes/UsuarioRoutes.js";
import routerEcoponto from "./Routes/EcopontoRoutes.js";
import routerLixeira from "./Routes/LixeiraRoutes.js";

const app = express();
const PORT = Number(process.env.PORT || 5000);

const frontendUrl = process.env.FRONTEND_URL;
if (!frontendUrl) {
  throw new Error("FRONTEND_URL não configurada no arquivo .env");
}

app.use(cors({
  origin: frontendUrl,
  credentials: true,
}));

app.use(express.json());
app.use(cookieParser());

// Rotas da API
app.use("/ecofluxo", routerUsuario);
app.use("/ecopontos", routerEcoponto);
app.use("/lixeiras", routerLixeira);

// Swagger
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const swaggerPath = path.join(__dirname, "swagger_output.json");

if (fs.existsSync(swaggerPath)) {
  const swaggerFile = JSON.parse(fs.readFileSync(swaggerPath, "utf-8"));
  app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerFile));
} else {
  console.warn("swagger_output.json não encontrado. Execute npm run swagger.");
}

app.listen(PORT, () => {
  console.log(`Servidor EcoFluxo rodando na porta ${PORT}`);
  console.log(`Swagger: http://localhost:${PORT}/docs`);
});
