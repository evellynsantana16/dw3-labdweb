import type { Request, Response, NextFunction } from "express";
import jwt, { type JwtPayload } from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET;

export interface UsuarioPayload extends JwtPayload {
  id: number;
  nome: string;
  email: string;
  perfil: "MORADOR" | "GESTOR";
}

export interface AuthRequest extends Request {
  user?: UsuarioPayload;
}

function payloadValido(payload: string | JwtPayload): payload is UsuarioPayload {
  if (typeof payload !== "object" || payload === null) {
    return false;
  }

  return (
    typeof payload.id === "number" &&
    typeof payload.nome === "string" &&
    typeof payload.email === "string" &&
    (payload.perfil === "MORADOR" || payload.perfil === "GESTOR")
  );
}

// Autenticação: valida o token enviado no cookie "token".
export const autenticacaoToken = (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const token = req.cookies?.token;

  if (!token) {
    return res.status(401).json({ message: "Acesso negado. Faça login." });
  }

  if (!JWT_SECRET) {
    console.error("JWT_SECRET não configurada.");
    return res.status(500).json({ message: "Configuração de autenticação ausente." });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    if (!payloadValido(decoded)) {
      res.clearCookie("token");
      return res.status(403).json({ message: "Token inválido." });
    }

    req.user = decoded;
    return next();
  } catch {
    res.clearCookie("token");
    return res.status(403).json({ message: "Token inválido ou expirado." });
  }
};

// Autorização: permite somente o perfil informado.
export const autorizacaoPerfil = (
  perfilPermitido: "MORADOR" | "GESTOR"
) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: "Não está autenticado." });
    }

    if (req.user.perfil !== perfilPermitido) {
      return res.status(403).json({ message: "Acesso negado." });
    }

    return next();
  };
};
